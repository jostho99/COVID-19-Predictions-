"""
author: Josh Peterson

Creating a python script that runs git code.

What's needed:
Firstly you need git and you need to setup a remote sparse checkout for
the respository you want
Followed by setting up what folders/files you want to pull from the respository
using echo "some/dir/" >> .git/info/sparse-checkout on the git bash 
Finally use this script to automate the pull requests

Goal:
We have data we already want but want to automate the system to 
get data for us instead of manually downloading every time

"""

import subprocess

subprocess.call(["git", "pull", "origin", "master"])