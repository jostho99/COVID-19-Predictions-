This is the readme file to explain how to use the automated pull system.

Creating a python script that runs git code.

What's needed:
Firstly you need git and you need to setup a remote sparse checkout for
the respository you want - https://stackoverflow.com/questions/600079/how-do-i-clone-a-subdirectory-only-of-a-git-repository/13738951#13738951

Followed by setting up what folders/files you want to pull from the respository
using echo "some/dir/" >> .git/info/sparse-checkout on the git bash 

git init
git remote add -f origin https://github.com/CSSEGISandData/COVID-19
git config core.sparseCheckout true
echo "/csse_covid_19_data/csse_covid_19_daily_reports/" >> .git/info/sparse-checkout
git pull origin master

Finally use this script to automate the pull requests

